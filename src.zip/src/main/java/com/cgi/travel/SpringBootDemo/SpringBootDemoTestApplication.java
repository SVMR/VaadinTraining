package com.cgi.travel.SpringBootDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages = { "com.cgi.*" })
@EntityScan(basePackages = "com.cgi.*")

public class SpringBootDemoTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootDemoTestApplication.class, args);
	}
}
