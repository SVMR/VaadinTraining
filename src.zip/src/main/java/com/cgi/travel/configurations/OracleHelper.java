package com.cgi.travel.configurations;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cgi.travel.models.Flight;

@Configuration
public class OracleHelper {
	private static final String PERSISTENCE_UNIT_NAME = "cgitravel";
    private static EntityManagerFactory factory;
    
    /*
    @Bean
    public static EntityManager entityManager(EntityManagerFactory entityManagerFactory) {
        return entityManagerFactory.createEntityManager();
    }
    */
    @Bean
    public static EntityManagerFactory createEntityManagerFactory() {
        return Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
    }
    public static void processData(Flight flight) {
        factory =createEntityManagerFactory();
        EntityManager em = factory.createEntityManager();
        System.out.println(flight.getFlightCode());
        System.out.println(flight.getServiceOperator());
        System.out.println(flight.getFromCity());
        System.out.println(flight.getToCity());
        // read the existing entries and write to console
        /*
        Query q = em.createQuery("select flight from Flight flight");
        List<Flight> flightList = q.getResultList();
        for (Flight flightObj : flightList) {
            System.out.println(flightObj);
        }
        System.out.println("Size: " + flightList.size());
        */
        // create new Customer
        em.getTransaction().begin();
       
        
        em.persist(flight);
        em.getTransaction().commit();

        em.close();
    }
}
