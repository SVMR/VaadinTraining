package com.cgi.travel.configurations;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cgi.travel.models.Flight;

@Configuration
public class OracleHelper {
	private static final String PERSISTENCE_UNIT_NAME = "cgitravel";
	private static EntityManagerFactory factory;
	static EntityManager em;

	/*
	 * @Bean public static EntityManager entityManager(EntityManagerFactory
	 * entityManagerFactory) { return
	 * entityManagerFactory.createEntityManager(); }
	 */
	@Bean
	public static EntityManagerFactory createEntityManagerFactory() {
		return Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
	}

	public static List<Flight> getFilteredFlights(long fCode) {
		factory = createEntityManagerFactory();
		em = factory.createEntityManager();

		// read the existing entries and write to console
		Query q = null;
		if (fCode > 0) {
			q = em.createQuery("select f from Flight f where f.flightCode=?");
			q.setParameter("code", fCode);
		} else
			q = em.createQuery("select f from Flight f");
		List<Flight> flightList = q.getResultList();
		for (Flight flightObj : flightList) {
			System.out.println(flightObj);
		}

		System.out.println("Size: " + flightList.size());
		em.close();
		return flightList;
	}

	public static void processData(Flight flight) {
		factory = createEntityManagerFactory();
		em = factory.createEntityManager();
		System.out.println(flight.getFlightCode());
		System.out.println(flight.getServiceOperator());
		System.out.println(flight.getFromCity());
		System.out.println(flight.getToCity());

		// create new Customer
		em.getTransaction().begin();

		em.persist(flight);
		em.getTransaction().commit();

		em.close();
	}
}
