package com.cgi.travel.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="ING_Flight")
public class Flight {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator = "FLT_SEQ")
	@SequenceGenerator(sequenceName = "flight_seq", allocationSize = 1, name = "FLT_SEQ")
	@Column(name="Flight_Code")
	private String flightCode;
	@Column(name="Service_Operator",nullable=false,length=20)
	private String serviceOperator;
	@Column(name="From_City",nullable=false,length=20)
	private String fromCity;
	@Column(name="To_City",nullable=false,length=20)
	private String toCity;

	public String getFlightCode() {
		return flightCode;
	}

	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}

	public String getServiceOperator() {
		return serviceOperator;
	}

	public void setServiceOperator(String serviceOperator) {
		this.serviceOperator = serviceOperator;
	}

	public String getFromCity() {
		return fromCity;
	}

	public void setFromCity(String fromCity) {
		this.fromCity = fromCity;
	}

	public String getToCity() {
		return toCity;
	}

	public void setToCity(String toCity) {
		this.toCity = toCity;
	}

}
