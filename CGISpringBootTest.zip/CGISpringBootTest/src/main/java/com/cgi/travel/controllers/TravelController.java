package com.cgi.travel.controllers;


import java.util.Hashtable;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.cgi.travel.configurations.OracleHelper;
import com.cgi.travel.models.Flight;

@RestController
public class TravelController {

 @RequestMapping(path="/",method=RequestMethod.GET, produces="application/json")	
 public Hashtable<Integer,String> getFlightData()
 {
	 Hashtable<Integer,String> flightData=new Hashtable<Integer,String>();
	 flightData.put(38654, "Indigo");
	 flightData.put(42688, "Spicejet");
	 return flightData;
	 
 }
 @RequestMapping(path="/addData",method=RequestMethod.POST, produces="application/json")	
 public String addFlight(@RequestBody Flight flight)
 {
	 System.out.println(flight);
	 if(flight!=null)
	 {
		 OracleHelper.processData(flight);
		 return flight.getServiceOperator().toString();
	 }
	 else
	 return "No record found";
	 
 }	
	
}
