package com.cgi.travel.controllers;

public enum ServiceOperator {
    Indigo, Spicejet, Jetairways, GoAir, Vistara
}